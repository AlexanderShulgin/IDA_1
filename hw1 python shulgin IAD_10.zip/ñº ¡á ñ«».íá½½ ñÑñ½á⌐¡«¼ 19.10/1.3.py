

s1 = input('введите первую строку')
s2 = input('введите вторую строку')
a,l = [], len(s1)
for i in range(l):
    s3 = ''
    for j in range(l):
        s3+=s1[(i+j) % l]
    a.append(s3)
print(s2 in a)
