s = input()
ns,summ ='', 0
alphabet = ['1','2','3','4','5','6','7','8','9','0']
for i in range(len(s)-1):
    if(s[i] in alphabet):
        ns+=s[i]
    elif(s[i+1] in alphabet):
        ns+='+'
if(s[len(s)-1] in alphabet):
    ns+=s[len(s)-1]
ns = ((ns.lstrip('+')).split('+'))
for i in ns:
    summ += int(i)
print(summ)
    
