def function (S, ntuple):
    summ=0
    for s in S:
        summ+=ntuple[0](s)
        
    maxim=summ
    count=0
    
    for i in range(len(ntuple)-1):
        summ=0
        for s in S:
            summ+=ntuple[i+1](s)
        if(summ>=maxim):
            maxim=summ
            count=i+1
    return ntuple[count]






            
