

s = input()
s = s.split(' ')
s.reverse()
print(' '.join(s))
