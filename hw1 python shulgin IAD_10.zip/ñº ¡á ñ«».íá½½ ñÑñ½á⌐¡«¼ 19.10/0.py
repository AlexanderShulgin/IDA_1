number = int(input())

numbercop = number
counter = 1
while(numbercop//10 > 0):
    numbercop = numbercop//10
    counter+=1
l=counter
notpal = False
while(l>1):
    if(number%10 == number //(10**(l-1))):
        number = (number - 10**(l-1)*(number //(10**(l-1))) - number%10)/10
    else:
        notpal = True
        break
    numbercop = number    
    counter = 1
    while(numbercop//10 > 0):
       numbercop = numbercop//10
       counter+=1
    l=counter
if(notpal):
    print('not palindrome')
else:
    print('palindrome')
    
            
