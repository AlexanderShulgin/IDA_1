s = input()
r = s.find('not')
while(r!=-1):
    l = s[r+3::].find('bad')
    if(l!=-1):
        s = s[0:r]+'good'+s[r+l+6::]
    else:
        break
    r = s.find('not')
print(s)        
    
    
