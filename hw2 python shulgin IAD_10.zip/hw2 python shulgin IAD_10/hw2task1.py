
def morecommon(a,b,n):
    c1,c2 = 0,0
    for i in a:
        if i%n ==0:
            c1+=1
    for i in b:
        if i%n==0:
            c2+=1
    if c1>c2:
        return True
    else:
        return False