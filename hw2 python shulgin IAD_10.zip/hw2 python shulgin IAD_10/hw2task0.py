mumbo = set()
jumbo = set()
ind = 1
while(True):
    s=input()
    if s=='':
        break
    if ind%2==1:
        for letter in s:
            mumbo.add(letter)
    else:
        for letter in s:
            jumbo.add(letter)
    ind+=1
if len(mumbo)>len(jumbo): #проверка того, что я назначил имена множествам правильно
    print('Mumbo')
else:
    print('Jumbo')
        
    
    